module.exports = {
  development:{
    username: "root", //process.env.DB_USERNAME,
    password: "password",  //process.env.DB_PASSWORD,
    database: "upm", //process.env.DB_NAME,
    host: "127.0.0.1", //process.env.DB_HOSTNAME,
    dialect: 'mysql',
    timezone: '+08:00',
    logging: false,
    pool: {
      max: 5,
      min: 0,
      acquire: 4000,
      idle: 10000                    
    }
  }
};
