# Node.js-Express-With-MySQL
This is a demo for node.je Express (ejs) with mysql
　
　
## Blog
[Node.js - MySQL](https://dotblogs.com.tw/explooosion/2016/07/18/010601)
　
　
　

 　　
## Clone
```bash
git clone https://github.com/explooosion/Node.js-Express-With-MySQL.git
```
　
## Into Project
```bash
cd Node.js-Express-With-MySQL
```
　
## Install
```bash
npm install
```
　
